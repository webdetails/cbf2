/*!
 * Copyright 2002 - 2017 Webdetails, a Hitachi Vantara company. All rights reserved.
 *
 * This software was developed by Webdetails and is provided under the terms
 * of the Mozilla Public License, Version 2.0, or any later version. You may not use
 * this file except in compliance with the license. If you need a copy of the license,
 * please go to http://mozilla.org/MPL/2.0/. The Initial Developer is Webdetails.
 *
 * Software distributed under the Mozilla Public License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. Please refer to
 * the license for the specific language governing your rights and limitations.
 */

define([], function() {

  return {

    sparklNewPluginCard:
      "   <div class='overlay'></div>" +
      "   <div class='optionsContainer'></div>" +
      "   <div class='separator'>" +
      "     <div class='horizontalRectangle'></div>" +
      "     <div class='verticalRectangle'></div>" +
      "   </div>",

    sparklPluginCard:
      "   <div class=descriptionExpandCont>" +
      "     <div class='cardHeader'>" +
      "       <div class='nameContainer'>" +
      "         <span class='name' title='{{plugin_name}}'>{{plugin_name}}</span>" +
      "       </div>" +
      "       <div class='id' title='{{pluginId}}'>{{pluginId}}</div>" +
      "     </div>" +
      "     <div class='cardBody'>" +
      "       <div class='imageContainer'>" +
      "       </div>" +
      "       <div class='descriptionContainer'>" +
      "         <div class='header'>Description</div>" +
      "         <div class='body'>{{plugin_description}}</div>" +
      "       </div>" +
      "     </div>" +
      "   </div>" +
      "   <div class='cardFooter'>" +
      "     <div class='optionsContainer'>" +
      "     </div>" +
      "   </div>"
  };
});